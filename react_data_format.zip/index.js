import dynamic from 'next/dynamic'
import OptimizedImageFullBleed from "../src/customComponents/OptimizedImage";
const Meta = dynamic(() => import('../src/customComponents/Meta'));
import homeStyles from "../styles/scss/home/Home.module.scss";
import CustomLink from "../src/customComponents/CustomLink";
import OptimizedImage from "../src/customComponents/OptimizedImage";
import ImageFullBleed from "../src/customComponents/OptimizedImageFullBleed";
import {rightArrow, takeATrip} from "../src/helpers/IconLists";
import {useEffect, useState} from "react";
import {getAllUsers} from "../src/api/customerApi";
import {sendServerSideRequest} from "../src/api/serverSideRequest";
import {Options} from "../src/helpers/options";

const Home = ({users}) => {
    const [data, setData] = useState(Options);

    useEffect(() => {
    }, []);

    return (
        <>
            <Meta title="Home" />
            <div className={homeStyles[`homepage-wr`]}>
                <main >
                    {
                        data.map((item, index) => {
                            if(item['fields']) {
                                return (
                                    <div>
                                        <div className={'container'}>

                                            {item['fields'].map((containers) => {
                                                return (
                                                    <div className={'row'}>
                                                            {containers.map((field) => {
                                                                return (
                                                                    <div className={`col-lg-${field.grid}`}>
                                                                        <label>{field.label}</label>
                                                                        <input
                                                                            type={field.type}
                                                                            placeholder={field.placeholder}
                                                                        />
                                                                    </div>
                                                                )
                                                            })}
                                                        </div>
                                                )
                                            })}
                                            </div>
                                    </div>
                                )
                            }
                        })
                    }
                    <section className={homeStyles[`homepage-wr_why-pay-to-me-section`]}>
                        <div className="container">
                            <div className={homeStyles[`why-pay-to-me-wr`]}>
                                <div className={`row`}>
                                    <div className={`col-lg-7 col-xl-6`}>
                                        <div className={homeStyles[`why-pay-to-me-wr_trip`]}>
                                            <div className={homeStyles[`trip-heading-area`]}>
                                                <p><span className={homeStyles[`trip-heading-area--heading-payment`]}>Payments System</span> <span className={homeStyles[`trip-heading-area--heading-payment-for`]}>For</span> <br />Business And Individual</p>
                                            </div>
                                            <div className={homeStyles[`trip-content-area`]}>
                                                <p>When the life too much things you need more than you have. Let’s PaytoME help your life to easier with <span className="public-page-text--semi-bold">smart payment system</span></p>
                                            </div>
                                            <div className={homeStyles[`trip-get-started-area`]}>
                                                <div className={homeStyles['trip-get-started-area_take-a-trip-wr']}>
                                                    <CustomLink href={''}>
                                                        {takeATrip}
                                                    </CustomLink>
                                                </div>
                                                <div className={homeStyles['trip-get-started-area_get-started-btn']}>
                                                    <CustomLink href={''}>
                                                        <span>Get Started</span>
                                                        <span>{rightArrow}</span>
                                                    </CustomLink>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className={`col-lg-5 col-xl-6`}>
                                        <div className={homeStyles[`why-pay-to-me-wr_request-payment`]}>
                                            <div className={homeStyles[`request-payment-image-area`]}>
                                                <OptimizedImageFullBleed
                                                    imgUrl={'/assets/images/common/header-request-payment-illustration.png'}
                                                    imgAlt={'Request Payment'}
                                                    priority={true}
                                                    imgClass={`header-request-payment-illustration`}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className={homeStyles[`homepage-wr_easiest-way-to-send-section`]}>

                        <div className={homeStyles[`easiest-way-to-send-wr`]}>
                            <div className={homeStyles[`easiest-way-to-send-wr_heading-area`]}>
                                <div className="container">
                                    <div className={homeStyles[`heading-area--heading`]}>
                                        <p><span className={`public-page-text--bold`}>Easiest Way To Send - </span>Receive Money and Manage Invoices</p>
                                    </div>
                                    <div className={homeStyles[`heading-area--content`]}>
                                        <p>When the life too much things you need more than you have. Let PayToME help your life to easier with <span className={`public-page-text--bold`}>smart payment system</span></p>
                                    </div>
                                </div>
                            </div>
                            <div className={homeStyles[`easiest-way-to-send-wr_get-started-and-learn-more-wr`]}>
                                <div className={homeStyles[`easiest-way-section-background`]}>
                                    <ImageFullBleed
                                        imgClass={'easiest-way-section-background-img'}
                                        imgUrl={'/assets/images/homepage/easiest-way-section-background.jpg'}
                                        imgAlt={'easiest-way-section-background-img'}
                                        priority={true}
                                    />
                                </div>
                                <div className="container">
                                    <div className={homeStyles[`get-started-area`]}>
                                        <div className={`row`}>
                                            <div className={`col-lg-6`}>
                                                <div className={homeStyles[`each-get-started-area-wr`]}>
                                                    <div className={homeStyles[`each-get-started-area-wr_image-wr`]}>
                                                        <OptimizedImage
                                                            imgClass={'manage-customer'}
                                                            imgUrl={'/assets/images/homepage/manage-customer.png'}
                                                            imgAlt={'manage-customer'}
                                                            priority={true}
                                                            width={'395px'}
                                                            height={'295px'}
                                                        />
                                                    </div>
                                                    <div className={homeStyles[`each-get-started-area-wr_content-wr`]}>
                                                        <p>Manage customer and vendor Send, Receive invoices, and pay with your phone</p>
                                                    </div>
                                                    <div className={homeStyles[`each-get-started-area-wr_button-wr`]}>
                                                        <CustomLink className={homeStyles['get-started-bg-color']} href={''}>Get Started</CustomLink>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className={`col-lg-6`}>
                                                <div className={homeStyles[`each-get-started-area-wr`]}>
                                                    <div className={homeStyles[`each-get-started-area-wr_image-wr`]}>
                                                        <OptimizedImage
                                                            imgClass={'send-money'}
                                                            imgUrl={'/assets/images/homepage/send-money.png'}
                                                            imgAlt={'send-money'}
                                                            priority={true}
                                                            width={'306px'}
                                                            height={'295px'}
                                                        />
                                                    </div>
                                                    <div className={homeStyles[`each-get-started-area-wr_content-wr`]}>
                                                        <p>Send money to your friends or relatives instantly</p>
                                                    </div>
                                                    <div className={homeStyles[`each-get-started-area-wr_button-wr`]}>
                                                        <CustomLink href={''}>Get Started</CustomLink>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className={homeStyles[`learn-more-area`]}>
                                        <div className={`row`}>
                                        <div className={`col-lg-4`}>
                                            <div className={homeStyles[`each-learn-more-area-wr`]}>
                                                <div className={homeStyles[`each-learn-more-area-wr_image-wr`]}>
                                                    <OptimizedImage
                                                        imgUrl={'/assets/images/homepage/most-secure.png'}
                                                        imgAlt={'Most Secure Credit'}
                                                        priority={true}
                                                        width={'235px'}
                                                        height={'230px'}
                                                    />
                                                </div>
                                                <div className={homeStyles[`each-learn-more-area-wr_content-wr`]}>
                                                    <p>Most secure credit & debit card.Including advanced FCVV Security System</p>
                                                </div>
                                                <div className={homeStyles[`each-learn-more-area-wr_button-wr`]}>
                                                    <CustomLink href={''}>Learn More</CustomLink>
                                                </div>
                                            </div>
                                        </div>
                                        <div className={`col-lg-4`}>
                                            <div className={homeStyles[`each-learn-more-area-wr`]}>
                                                <div className={homeStyles[`each-learn-more-area-wr_image-wr`]}>
                                                    <OptimizedImage
                                                        imgUrl={'/assets/images/homepage/advance-cash.png'}
                                                        imgAlt={'Advanced Cash'}
                                                        priority={true}
                                                        width={'300px'}
                                                        height={'230px'}
                                                    />
                                                </div>
                                                <div className={homeStyles[`each-learn-more-area-wr_content-wr`]}>
                                                    <p>Advance cash register for retail stores</p>
                                                </div>
                                                <div className={homeStyles[`each-learn-more-area-wr_button-wr`]}>
                                                    <CustomLink href={''}>Learn More</CustomLink>
                                                </div>
                                            </div>
                                        </div>
                                        <div className={`col-lg-4`}>
                                            <div className={homeStyles[`each-learn-more-area-wr`]}>
                                                <div className={homeStyles[`each-learn-more-area-wr_image-wr`]}>
                                                    <OptimizedImage
                                                        imgUrl={'/assets/images/homepage/send-money-directly.png'}
                                                        imgAlt={'send-money-directly'}
                                                        priority={true}
                                                        width={'235px'}
                                                        height={'230px'}
                                                    />
                                                </div>
                                                <div className={homeStyles[`each-learn-more-area-wr_content-wr`]}>
                                                    <p>Manage your teen's debit card.Send money directly when you need it</p>
                                                </div>
                                                <div className={homeStyles[`each-learn-more-area-wr_button-wr`]}>
                                                    <CustomLink href={''}>Learn More</CustomLink>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </section>
                </main>
            </div>
        </>
    )
}
export async function getServerSideProps() {
    const res = await sendServerSideRequest('https://jsonplaceholder.typicode.com/users/');
    const data = await res.json()
    return {
        props: {
            users: data
        }
    }
}

export default Home;