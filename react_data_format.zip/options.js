export const Options = [
    {
        fields: [
            [{
                name: "first_name",
                label: "First Name",
                type: "textField",
                placeholder: "Enter Your First Name",
                status: true,
                grid: "4"
            },
            {
                name: "last_name",
                label: "Last Name",
                type: "textField",
                placeholder: "Enter Your Last Name",
                status: true,
                grid: "4"
            }],
            [{
                name: "email",
                label: "Email",
                type: "email",
                placeholder: "Enter Your Email",
                status: true,
                grid: "4"
            },
            {
                name: "password",
                label: "Password",
                type: "password",
                placeholder: "Enter Your password",
                status: true,
                grid: "4"
            }]
        ],
        buttons: [
            {
                label: 'submit'
            }
        ],
        actions: [
            {
                api: {
                    fetch: "https://jsonplaceholder.typicode.com/users/",
                    create: "",
                    update: "",
                    delete: ""
                }
            }
        ]
    }
]